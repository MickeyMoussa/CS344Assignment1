
Summary of what was done in each task:

A.1:

Used the symmetric cryptoscheme to encrypt and decrypt messages. Additionally, I explored different encoding schemes for the cryptocode.

A.2:

Implemented RSA in Ubuntu. Explored the syntax to generate the private key and how the private key is used to generate the public key. After generating both, I explored how to encrypt and decrypt with the scheme like in A.1

A.3:

Analyzed the certificate of authentication of for the Saudi Data & AI Authority: this included checking that DigiCert is the issuer, the cryptosystem in use, which happened to be RSA, as well as the validity period.

A.4:

Simulated a communication line where we have two parties (Alice and Bob), and an authenticating authority (kfupm_ca). I used the Ubuntu shell to walkthrough the entire verification and process:
1. checking the authenticity of the certificate of Bob using kfupm_ca's public key
2. encrypting the message using Bob's public key after verifying it to maintain confidentiality
3. sending a signature along with the cryptocode such that Bob can verify the authenticity and integrity of the message

A.5:

Answered theoritical questions about the the CA authentication process and why SHA-1 is considered outdated/broken. 